import java.awt.Color;
import java.awt.Font;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class RadioButtonTestFromYoutube
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

      	// Objects to enter input and display
		JLabel companyLabel = new JLabel("Bryant's Car Rental");
		JLabel iconLabel;
		JLabel nameLabel = new JLabel("Customer Name: ");
		JTextField nameTextField = new JTextField(20);
		JLabel daysRentedLabel = new JLabel("Days Rented: ");
		JTextField daysRentedTextField = new JTextField(20);
		JLabel milesDrivenLabel = new JLabel("Miles Driven: ");
		JTextField milesDrivenTextField = new JTextField(20);
		JButton calculateButton = new JButton("Rental");
		JButton summaryButton = new JButton("Summary");
		JButton clearButton = new JButton("Clear");
		JTextArea outputTextArea = new JTextArea(3, 20);
		JScrollPane outputScrollPane = new JScrollPane(outputTextArea);  //For scroll bars around text area
		
		
		JFrame frame = new JFrame();
		frame.setTitle("Radio");
		frame.setSize(320, 500);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
    //	JPanel mainPanel = new JPanel();
		iconLabel = new JLabel(new ImageIcon("eco_green_car_icon.jpg"));
		

		JPanel optionsPanel = new JPanel();
		JPanel buttonsPanel = new JPanel();
		
    	JLabel programmerNameLabel = new JLabel("\n Maintained by Bryant Tunbutr");

    	Font bigFont = new Font("Times New Roman", Font.BOLD, 28);
    	

		panel.add(iconLabel);
		panel.add(companyLabel);
		panel.add(nameLabel);
		panel.add(nameTextField);
		panel.add(daysRentedLabel);
		panel.add(daysRentedTextField);
		panel.add(milesDrivenLabel);
		panel.add(milesDrivenTextField);
				
		companyLabel.setFont(bigFont);
		companyLabel.setForeground(Color.RED);
		
		JRadioButton economy = new JRadioButton();
		economy.setText("Economy");
		JRadioButton midsize = new JRadioButton();
		midsize.setText("Mid-Size");
		JRadioButton fullsize = new JRadioButton();
		fullsize.setText("Full-Size");
		JRadioButton luxury = new JRadioButton();
		luxury.setText("Luxury");
		
		JCheckBox navigationCheckBox = new JCheckBox("Navigation System");
		
		ButtonGroup group = new ButtonGroup();
		group.add(economy);
		group.add(midsize);
		group.add(fullsize);
		group.add(luxury);

		panel.add(economy);
		panel.add(midsize);
		panel.add(fullsize);
		panel.add(luxury);
		

		optionsPanel.add(navigationCheckBox);
		panel.add(optionsPanel);
		
		buttonsPanel.add(calculateButton);
		buttonsPanel.add(summaryButton);
		buttonsPanel.add(clearButton);

    	panel.add(buttonsPanel);    	
    	panel.add(outputScrollPane);
    	panel.add(programmerNameLabel);
		
		frame.getContentPane().add(panel);
		frame.setVisible(true);

	}

}
