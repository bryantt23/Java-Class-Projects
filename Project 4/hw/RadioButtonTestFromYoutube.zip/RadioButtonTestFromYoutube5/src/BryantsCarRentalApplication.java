import java.awt.Color;
import java.awt.Font;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


import javax.swing.*;		//used for the swing components
import java.awt.event.*;	//used for the ActionListener
import java.text.*;			//used for the DecimalFormat class


public class BryantsCarRentalApplication extends JFrame 
implements ActionListener
{

  	// Objects to enter input and display
	JLabel companyLabel = new JLabel("Bryant's Car Rental");
	JLabel iconLabel;
	JLabel nameLabel = new JLabel("Customer Name: ");
	JTextField nameTextField = new JTextField(20);
	JLabel daysRentedLabel = new JLabel("Days Rented: ");
	JTextField daysRentedTextField = new JTextField(20);
	JLabel milesDrivenLabel = new JLabel("Miles Driven: ");
	JTextField milesDrivenTextField = new JTextField(20);
	JButton calculateButton = new JButton("Rental");
	JButton summaryButton = new JButton("Summary");
	JButton clearButton = new JButton("Clear");
	JTextArea outputTextArea = new JTextArea(5, 20);
	JScrollPane outputScrollPane = new JScrollPane(outputTextArea);  //For scroll bars around text area
	

	JRadioButton invisible = new JRadioButton();
	
	//variables
	int daysRentedInteger, milesDrivenInteger, daysRentedTotalInteger, milesDrivenTotalInteger;
	// 	float totalSalesFloat;
	
	//constants
	final float ECONOMY_DAILY_RATE_FLOAT = 26;
	final float MIDSIZE_DAILY_RATE_FLOAT = 40;
	final float FULLSIZE_DAILY_RATE_FLOAT = 65;
	final float LUXURY_DAILY_RATE_FLOAT = 85;

	final float ECONOMY_MILEAGE_RATE_FLOAT = 0.15F;
	final float MIDSIZE_MILEAGE_FLOAT = 0.18F;
	final float FULLSIZE_MILEAGE_RATE_FLOAT = 0.25F;
	final float LUXURY_MILEAGE_RATE_FLOAT = 0.40F;

	//This method will create an object of ourselves and set the default close operation
	public static void main(String[] args)
	{
		BryantsCarRentalApplication myProgram = new BryantsCarRentalApplication();
		myProgram.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
	

	//This is the constructor and will add the components to the GUI, 
	//register the listeners, and set the properties of the JFrame
	public BryantsCarRentalApplication()
	{
		//This is the constructor and will add the components to the GUI, 
		//register the listeners, and set the properties of the JFrame
				
		JFrame frame = new JFrame();
		frame.setTitle("Radio");
		frame.setSize(320, 550);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		
		iconLabel = new JLabel(new ImageIcon("eco_green_car_icon.jpg"));
		
		JPanel optionsPanel = new JPanel();
		JPanel buttonsPanel = new JPanel();
		
    	JLabel programmerNameLabel = new JLabel("\n Maintained by Bryant Tunbutr");

    	Font bigFont = new Font("Times New Roman", Font.BOLD, 28);
    	
		panel.add(iconLabel);
		panel.add(companyLabel);
		panel.add(nameLabel);
		panel.add(nameTextField);
		panel.add(daysRentedLabel);
		panel.add(daysRentedTextField);
		panel.add(milesDrivenLabel);
		panel.add(milesDrivenTextField);
				
		companyLabel.setFont(bigFont);
		companyLabel.setForeground(Color.RED);
		
		JRadioButton economy = new JRadioButton();
		economy.setText("Economy");
		JRadioButton midsize = new JRadioButton();
		midsize.setText("Mid-Size");
		JRadioButton fullsize = new JRadioButton();
		fullsize.setText("Full-Size");
		JRadioButton luxury = new JRadioButton();
		luxury.setText("Luxury");
//		JRadioButton invisible = new JRadioButton();
		
		//deselect all radio buttons by selecting the invisible radio button
		invisible.setSelected(true);
		
		JCheckBox navigationCheckBox = new JCheckBox("Navigation System");
		
		ButtonGroup group = new ButtonGroup();
		group.add(economy);
		group.add(midsize);
		group.add(fullsize);
		group.add(luxury);
		group.add(invisible);

		panel.add(economy);
		panel.add(midsize);
		panel.add(fullsize);
		panel.add(luxury);		

		optionsPanel.add(navigationCheckBox);
		panel.add(optionsPanel);
		
		buttonsPanel.add(calculateButton);
		buttonsPanel.add(summaryButton);
		buttonsPanel.add(clearButton);

    	panel.add(buttonsPanel);    	
    	panel.add(outputScrollPane);
    	panel.add(programmerNameLabel);
		
		frame.getContentPane().add(panel);
		frame.setVisible(true);

		//add the objects to the actionlistener
		milesDrivenTextField.addActionListener(this);
		calculateButton.addActionListener(this);
		clearButton.addActionListener(this);
		
	}


	//This method will check for which component triggered this method.
	//If the purchase button or the priceTextField is the trigger, call 
	//the validation method, and if OK, call the purchase method
	//If the summary button is the trigger, call the summary method
	public void actionPerformed(ActionEvent evt)
	{
		//
	    Object sourceObject = evt.getSource();
	    
	    if(sourceObject == calculateButton || sourceObject == milesDrivenTextField)
	    {
	    	if(validation())
	    		purchase();
	    }
	    if(sourceObject == clearButton)
	    {
	    	clearTextFields();
	    }

	}
	

	//Validate all text fields to ensure that some entry was made in each
	//Send an appropriate error message, if no entry was made and reset the insertion point
	public boolean validation()
	{
	    boolean validationBoolean;
	    
	    if(!(nameTextField.getText()).equals(""))
	    {
			if(!(daysRentedTextField.getText()).equals(""))
			{
				if(!(milesDrivenTextField.getText()).equals(""))
				{
				validationBoolean = true; 
				}
/*
				if ()
				{
					validationBoolean = true; 
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Please pick car");
					validationBoolean = false;
				}
	*/				
				else
				{
				JOptionPane.showMessageDialog(null, "Please miles driven");
				milesDrivenTextField.requestFocus();
				validationBoolean = false;
				}
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Please enter days rented");
				daysRentedTextField.requestFocus();
				validationBoolean = false;
			}
	    }
	    else
	    {
			JOptionPane.showMessageDialog(null, "Please enter name");
			nameTextField.requestFocus();
			validationBoolean = false;
	    }
	    return validationBoolean;
	
	}
	
	
	
	//This method will retrieve and convert the data from the components,
	//calculate the subtotal, accumulate the totals, display the result, and 
	//reset the textfields for the next entry
	public void purchase()
	{
	    //local variables
	    String nameString, daysRentedString, milesDrivenString;
	 
		//retrieve the input from the  user
		nameString = nameTextField.getText();
		daysRentedString = daysRentedTextField.getText();
		milesDrivenString = milesDrivenTextField.getText();
		
		//change data types
		daysRentedInteger = Integer.parseInt(daysRentedString);
		milesDrivenInteger = Integer.parseInt(milesDrivenString);
				
		//accumulate  the totals
		daysRentedTotalInteger += daysRentedInteger;
		milesDrivenTotalInteger += milesDrivenInteger;
		
		//display
		displayRental(daysRentedInteger, milesDrivenInteger, daysRentedTotalInteger, milesDrivenTotalInteger);
				
		//clear textfields
		//		clearTextFields();
	}
	
	//This method will format the result and display appropriate information in the textarea
	public void displayRental(int daysRentedInteger, int milesDrivenInteger, int daysRentedTotalInteger, int milesDrivenTotalInteger)
	{
		//Format the values to currency format
		DecimalFormat valueDecimalFormat = new DecimalFormat("$#0.00");
		//display the total for the customer
		outputTextArea.setText(
				"Name  " + nameTextField.getText() + '\n' +
				"daysRentedString  " + valueDecimalFormat.format(daysRentedInteger) + '\n' +
				"milesDrivenString  " + valueDecimalFormat.format(milesDrivenInteger) + '\n' +
				"daysRentedTotalInteger  " + '\t' + valueDecimalFormat.format(daysRentedTotalInteger) + '\n' +
				"milesDrivenTotalInteger  " + valueDecimalFormat.format(milesDrivenTotalInteger)
				);
	}
		

	//This method will clear the input fields for the next entry
	public void clearTextFields()
	{
	    //clear the text fields
		nameTextField.setText("");
		daysRentedTextField.setText("");
		milesDrivenTextField.setText("");
	
		//place the cursor back in the name text field
		nameTextField.requestFocus();
		
		//deselect all radio buttons by selecting the invisible radio button
		invisible.setSelected(true);

		

	}

}
