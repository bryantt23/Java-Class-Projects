//folder/Project name: ShippingCharge
//Programmer name: Bryant Tunbutr
//Date: 3/20/13
//Class name: ShippingCharge
/*Project Description: This project will accept a package's 6 digit 
 * identification code and weight,
 * the first name of the user from a dialog box, calculate the shipping charge
 * and display them to the user in the console area.*
 */

import java.util.Scanner;
import javax.swing.*;

public class ShippingChargeApplication
{

	/* This project will accept a package's 6 digit 
	 * identification code and weight,
	 * the first name of the user from a dialog box, calculate the shipping charge
	 * and display them to the user in the console area.*
	 */

	public static void main(String[] args)
	{
		//Declare local variables
		String firstNameString = "";
		String identificationCodeString = "";
		float packageWeightFloat;
		float shippingChargeFloat = 0;

		//Declare constants needed
		final float SHIPPING_RATE_FLOAT = .12F;

		//Declare objects needed
		Scanner inputScanner = new Scanner (System.in);
		
		//Retrieve input from the user		
		firstNameString = JOptionPane.showInputDialog("Please enter your first name");			
		System.out.print("Please enter the 6-digit Identification Code: ");
		identificationCodeString = inputScanner.next();		
		System.out.print("Please enter the weight in ounces: ");		
		packageWeightFloat = inputScanner.nextFloat();
		
		//Complete the needed calculations
		shippingChargeFloat = packageWeightFloat * SHIPPING_RATE_FLOAT;
		
		//Display the results to the user
		System.out.println("Name:           " + firstNameString);
		System.out.println("Package ID:     " + identificationCodeString);
		System.out.println("Weight:         " + packageWeightFloat);
		System.out.println("Shipping costs: " + shippingChargeFloat);
		
	}//end of main

}//end of ShellApplication class
